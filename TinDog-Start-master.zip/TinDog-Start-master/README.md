TinDog Starting Files
